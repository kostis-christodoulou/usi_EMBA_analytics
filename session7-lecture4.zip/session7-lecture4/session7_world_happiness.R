library(tidyverse)
library(broom)
library(GGally)
library(here)
library(janitor)
library(huxtable)
library(skimr)

world_happiness_15 <- read_csv(here("data", "world_happiness_2015.csv")) %>% 
  janitor::clean_names()

# inspect dataframe; how many observations, kinds of variables, etc.
glimpse(world_happiness_15)

# produce scatterplot-correlation matrix using GGally::ggpairs()
world_happiness_15 %>% 
  select(-c(country, region, happiness_rank, standard_error)) %>% 
  ggpairs()


# produce sumamry statistics for happiness score
world_happiness_15 %>% 
  select(happiness_score) %>% 
  skim()

# fir 3 models, with model1 being just the mean happiness
model1 <- lm(happiness_score ~ 1, data = world_happiness_15)
model2 <- lm(happiness_score ~ freedom, data = world_happiness_15)
model3 <- lm(happiness_score ~ economy_gdp_per_capita + freedom, data = world_happiness_15)

# get model summary and R2, etc for both models
model2 %>% broom::tidy(conf.int = TRUE)
model2 %>% broom::glance()

model3 %>% broom::tidy(conf.int = TRUE)
model3 %>% broom::glance()


# produce summary table comparing models using huxtable::huxreg()
huxreg(model1, model2, model3,
       statistics = c('#observations' = 'nobs', 
                      'R squared' = 'r.squared', 
                      'Adj. R Squared' = 'adj.r.squared', 
                      'Residual SE' = 'sigma'), 
       bold_signif = 0.05, 
       stars = NULL
) %>% 
  set_caption('Comparison of models')

